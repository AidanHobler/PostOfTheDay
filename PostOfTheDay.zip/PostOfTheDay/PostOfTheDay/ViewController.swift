//
//  ViewController.swift
//  PostOfTheDay
//
//  Created by Aidan Hobler on 11/18/19.
//  Copyright © 2019 Aidan Hobler. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Test"
        view.backgroundColor = .systemRed
        // Do any additional setup after loading the view.
    }


}

